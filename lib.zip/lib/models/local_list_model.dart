class LocalListModel {
  final String interest;
  final String image;

  LocalListModel({required this.interest, required this.image});
}
